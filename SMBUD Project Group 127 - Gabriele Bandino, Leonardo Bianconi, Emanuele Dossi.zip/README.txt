Instructions for installing the DBs from dumps:
- Neo4J: dump/neo4j-db.dump is already the dump file
- MongoDB: dump/mongoDB_dump.txt contains the link to a shared Drive folder.
    This folder comprises the full and the reduced ("red") DB dump.